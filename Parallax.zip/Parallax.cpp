#include <SFML/Graphics.hpp>

int main()
{
    sf::RenderWindow window(sf::VideoMode(500, 272), "Layer Movement");
    sf::Texture texture1;
    texture1.loadFromFile("background_1.png");


    sf::Texture texture2;
    texture2.loadFromFile("background_2.png");

    sf::Sprite sprite1(texture1);
    sf::Sprite sprite11(texture1);
    sf::Sprite sprite2(texture2);
    sf::Sprite sprite22(texture2);

    sprite1.setPosition(0.f, 0.f);
    sprite11.setPosition(texture1.getSize().x, 0.f);

    sprite2.setPosition(0.f, 0.f);
    sprite22.setPosition(texture2.getSize().x, 0.f);

    sf::Clock clock;

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        sf::Time elapsed = clock.restart();
        float deltaTime = elapsed.asSeconds();

        sprite1.move(-50.f * deltaTime, 0.f); // Front layer
        sprite11.move(-50.f * deltaTime, 0.f); 
        sprite2.move(-25.f * deltaTime, 0.f); // Back layer
        sprite22.move(-25.f * deltaTime, 0.f);
        if (sprite1.getPosition().x + texture1.getSize().x < 0)
            sprite1.setPosition(texture1.getSize().x, 0.f);
        if (sprite11.getPosition().x + texture1.getSize().x < 0)
            sprite11.setPosition(texture1.getSize().x, 0.f);
        if (sprite2.getPosition().x + texture1.getSize().x < 0)
            sprite2.setPosition(texture1.getSize().x, 0.f);
        if (sprite22.getPosition().x + texture1.getSize().x < 0)
            sprite22.setPosition(texture1.getSize().x, 0.f);
        window.clear();

        window.draw(sprite2);
        window.draw(sprite22);
        window.draw(sprite1);
        window.draw(sprite11);
        window.display();
    }

    return 0;
}
